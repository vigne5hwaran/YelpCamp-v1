#YelpCamp

* Add Landing Page
* Add Campgrounds Page that lists all campgrounds

Each campground has:
* Name 
* Image

#Layout and Basic Styling
* Create our Header and Footer Particles
* Add in Bootstrap(version 3.3.x Recommended)

#Creating new Campgrounds
* setup new campgrounds POST route
* Add in body-parser
* setup route to show form
* Add basic unstyled form

#Style the campgrounds page 
* Add a better header/title
* Make campgrounds display in a grid

#Style the Navbar and Form
* Add the navbar to all the Templates
* Style the new Campgrounds form